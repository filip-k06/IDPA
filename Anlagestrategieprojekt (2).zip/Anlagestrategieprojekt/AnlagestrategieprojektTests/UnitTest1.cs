using Anlagestrategieprojekt;
using System.Diagnostics;
using System.Reflection;

namespace AnlagestrategieprojektTests
{
    [TestFixture]
    public class Tests
    {
        private Form1 _form;

        [SetUp]
        public void Setup()
        {
            _form = new Form1();
        }

        [Test]
        public void TestMittelwert()
        {
            double[] input = { 1, 2, 3, 4, 5 };
            double expected = 3;
            double actual = _form.Mittelwert(input);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TestVarianz()
        {
            double[] input = { 1, 2, 3, 4, 5 };
            double expected = 2.5;
            double actual = _form.Varianz(input);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TestBerechneKorrelation()
        {
            double[] values1 = { 1, 2, 3 };
            double[] values2 = { 4, 5, 6 };
            double expected = 1;
            double actual = _form.BerechneKorrelation(values1, values2);
            Assert.AreEqual(expected, actual, 0.01);
        }

        [Test]
        public void TestPruefeEingabeInt_Valid()
        {
            string input = "123";
            bool expected = true;
            bool actual = _form.PruefeEingabeInt(input);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TestPruefeEingabeInt_Invalid()
        {
            string input = "abc";
            bool expected = false;
            bool actual = _form.PruefeEingabeInt(input);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TestBerechneDurchschnitt()
        {
            double[] renditen = { 1.0, 2.0, 3.0 };
            double expected = 2.0;
            double actual = Form1.BerechneDurchschnitt(renditen);
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void TestBerechneZukuenftigesKapital()
        {
            int kapital = 1000;
            double durchschnittlicheRendite = 0.05;
            double jahre = 10;
            double expected = 1628.894626777442;
            double actual = Form1.BerechneZukuenftigesKapital(kapital, durchschnittlicheRendite, jahre);
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [Test]
        public void TestBerechneJahreUmZielKapitalZuErreichen()
        {
            double aktuellesKapital = 1000;
            double zukuenftigesKapital = 2000;
            double rendite = 0.05;
            double expected = 14.2067;
            double actual = Form1.BerechneJahreUmZielKapitalZuErreichen(aktuellesKapital, zukuenftigesKapital, rendite);
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [Test]
        public void TestBerechneSicherheitsfaktor()
        {
            double varianz = 0.1;
            double korrelation = 0.8;
            double expected = 0.92909;
            double actual = Form1.BerechneSicherheitsfaktor(varianz, korrelation);
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [Test]
        public void TestBerechneGesamtwertung()
        {
            double varianz = 0.1;
            double korrelation = 0.8;
            int tageBisZiel = 365;
            double expected = 0.2545;
            double actual = Form1.BerechneGesamtwertung(varianz, korrelation, tageBisZiel);
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TearDown]
        public void TearDown()
        {
            if (_form != null)
            {
                _form.Dispose();
            }
        }
    }
}